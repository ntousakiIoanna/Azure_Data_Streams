
/***
@authors:   Kosmas Kanellakis t8200053, 
            Ioanna Ntousaki t8200125
***/


/*
Basic Variables :

- inputhub: the input coming from the event hub, through Generator.html file activation
- customerReference: input Reference source - the data come from Customer.json file 
- atmReference: input Reference source - the data come from Atm.json file
- areaReference: input Reference source - the data come from Area.json file
- output: sql query output will be placed there

*/



/*
Query 1:
Show the total “Amount” of “Type = 0” transactions at “ATM Code = 21” of the last 10 minutes. Repeat as new events
keep flowing in (use a sliding window).
*/
SELECT 
    sum(Amount) AS TotalAmount
INTO
    [output]
FROM
    [inputhub]
TIMESTAMP BY 
    EventEnqueuedUtcTime
WHERE 
    Type = 0 AND ATMCode = 21
GROUP BY  
    Amount, ATMCode, SlidingWindow(minute, 10)


/*
Query 2:
Show the total “Amount” of “Type = 1” transactions at “ATM Code = 21” of the last hour. Repeat once every hour
(use a tumbling window).
*/
SELECT
    SUM(Amount) AS TotalAmount
INTO
    [output]
FROM
    [inputhub]
TIMESTAMP BY 
    EventEnqueuedUtcTime
WHERE
    Type = 1
    AND ATMCode = 21
GROUP BY
    Type, ATMCode,TumblingWindow(hour, 1)


/*
Query 3:
Show the total “Amount” of “Type = 1” transactions at “ATM Code = 21” of the last hour. Repeat once every 30 minutes
(use a hopping window).
*/

SELECT
    SUM(Amount) AS TotalAmount
INTO
    [output]
FROM
    [inputhub]
TIMESTAMP BY 
    EventEnqueuedUtcTime
WHERE
    Type = 1
    AND ATMCode = 21
GROUP BY
    Type, ATMCode, HoppingWindow(Duration(hour, 1), Hop(minute, 30))


/*
Query 4:
Show the total “Amount” of “Type = 1” transactions per “ATM Code” of the last one hour (use a sliding window).
*/

SELECT
    ATMCode, SUM(Amount) AS TotalAmount
INTO
    [output]
FROM
    [inputhub]
TIMESTAMP BY 
    EventEnqueuedUtcTime
WHERE
    Type = 1
GROUP BY
    Type, ATMCode, SlidingWindow(hour, 1)

/*
Query 5:
Show the total “Amount” of “Type = 1” transactions per “Area Code” of the last hour. Repeat once every hour (use a
tumbling window).
*/

SELECT 
    [atmReference].[area_code], SUM([inputhub].[Amount]) AS Total_Amount
INTO 
    [output]
FROM 
    [inputhub]
TIMESTAMP BY 
    EventEnqueuedUtcTime
LEFT JOIN 
    [atmReference]
ON 
    [inputhub].[ATMCode] = [atmReference].[atm_code] 
GROUP BY 
    [atmReference].[area_code],[inputhub].[Type], TumblingWindow(hour, 1)
HAVING 
    [inputhub].[Type] = 1


/*
Query 6:
Show the total “Amount” per ATM’s “City” and Customer’s “Gender” of the last hour. Repeat once every hour (use a
tumbling window).
*/

SELECT 
    [areaReference].[area_city],[customerReference].[gender], SUM([inputhub].[Amount]) AS Total_Amount
INTO 
    [output]
FROM 
    [inputhub]
TIMESTAMP BY 
    EventEnqueuedUtcTime
LEFT JOIN 
    [atmReference]
ON 
    [inputhub].[ATMCode] = [atmReference].[atm_code] 
LEFT JOIN 
    [customerReference]
ON 
    [inputhub].[CardNumber] = [customerReference].[card_number] 
LEFT JOIN 
    [areaReference]
ON 
    [areaReference].[area_code] = [atmReference].[area_code]
GROUP BY  
    [areaReference].[area_city],[customerReference].[gender], TumblingWindow(hour, 1)


/*
Query 7:
Alert (SELECT “1”) if a Customer has performed two transactions of “Type = 1” in a window of an hour (use a sliding
window).
*/

SELECT 
    1 AS Alert, [customerReference].[last_name]
INTO
    [output]
FROM 
    [inputhub]
TIMESTAMP BY 
    EventEnqueuedUtcTime
LEFT JOIN 
    [customerReference]
ON 
    [customerReference].[card_number] = [inputhub].[CardNumber]
WHERE 
    [inputhub].[Type] = 1
GROUP BY 
    [customerReference].[last_name], SlidingWindow(hour, 1)
HAVING 
    COUNT(*) >= 2

/*
Query 8:
Alert (SELECT “1”) if the “Area Code” of the ATM of the transaction is not the same as the “Area Code” of the “Card
Number” (Customer’s Area Code) - (use a sliding window)
*/

SELECT 
    1 AS Alert
INTO 
    [output]
FROM 
    [inputhub]
TIMESTAMP BY 
    [inputhub].[EventEnqueuedUtcTime]
LEFT JOIN 
    [customerReference]
ON 
    [customerReference].[card_number] = [inputhub].[CardNumber]
LEFT JOIN 
    [atmReference]
ON 
    [atmReference].[atm_code] = [inputhub].[ATMCode]
WHERE 
    [atmReference].[area_code] <> [customerReference].[area_code]

